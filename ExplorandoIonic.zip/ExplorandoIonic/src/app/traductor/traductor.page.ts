import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { switchScan } from 'rxjs';

@Component({
  selector: 'app-traductor',
  templateUrl: './traductor.page.html',
  styleUrls: ['./traductor.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule],
})
export class TraductorPage implements OnInit {
  public translatedNum: string = '';
  public formData!: FormGroup;

  constructor() {}

  ngOnInit() {
    this.formData = new FormGroup({
      num: new FormControl(),
    });
  }

  onSubmit() {
    console.log(this.formData.value);
    const form = this.formData.value;
    const number = form.num;

    console.log(number);
    // switch (number) {
    //   case 1:
    //     this.translatedNum = 'Uno';
    //     break;
    //   case 2:
    //     this.translatedNum = 'Dos';
    //     break;
    //   case 3:
    //     this.translatedNum = 'Tres';
    //     break;
    //   case 4:
    //     this.translatedNum = 'Cuatro';
    //     break;
    //   case 5:
    //     this.translatedNum = 'Cinco';
    //     break;
    //   case 6:
    //     this.translatedNum = 'Seis';
    //     break;
    //   case 7:
    //     this.translatedNum = 'Siete';
    //     break;
    //   case 8:
    //     this.translatedNum = 'Ocho';
    //     break;
    //   case 9:
    //     this.translatedNum = 'Nueve';
    //     break;
    //   case 10:
    //     this.translatedNum = 'Diez';
    //     break;
    //   case 11:
    //     this.translatedNum = 'Once';
    //     break;
    //   case 12:
    //     this.translatedNum = 'Doce';
    //     break;
    //   case 13:
    //     this.translatedNum = 'Trece';
    //     break;
    //   case 14:
    //     this.translatedNum = 'Catorce';
    //     break;
    //   case 15:
    //     this.translatedNum = 'Quince';
    //     break;
    //   case 16:
    //     this.translatedNum = 'Dieciseis';
    //     break;
    //   case 17:
    //     this.translatedNum = 'Diecisiete';
    //     break;
    //   case 18:
    //     this.translatedNum = 'Dieciocho';
    //     break;
    //   case 19:
    //     this.translatedNum = 'Diecinueve';
    //     break;
    //   case 20:
    //     this.translatedNum = 'Veinte';
    //     break;
    //   case 21:
    //     this.translatedNum = 'Veintiuno';
    //     break;
    //   case 22:
    //     this.translatedNum = 'Veintidos';
    //     break;
    //   case 23:
    //     this.translatedNum = 'Veintitres';
    //     break;
    //   case 24:
    //     this.translatedNum = 'Veinticuatro';
    //     break;
    //   case 25:
    //     this.translatedNum = 'Veinticinco';
    //     break;
    //   case 26:
    //     this.translatedNum = 'Veintiseis';
    //     break;
    //   case 27:
    //     this.translatedNum = 'Veintisiete';
    //     break;
    //   case 28:
    //     this.translatedNum = 'Veintiocho';
    //     break;
    //   case 29:
    //     this.translatedNum = 'Veintinueve';
    //     break;
    //   case 30:
    //     this.translatedNum = 'Treinta';
    //     break;
    //   case 31:
    //     this.translatedNum = 'Treinta y uno';
    //     break;
    //   case 32:
    //     this.translatedNum = 'Treinta y dos';
    //     break;
    //   case 33:
    //     this.translatedNum = 'Treinta y tres';
    //     break;
    //   case 34:
    //     this.translatedNum = 'Treinta y cuatro';
    //     break;
    //   case 35:
    //     this.translatedNum = 'Treinta y cinco';
    //     break;
    //   case 36:
    //     this.translatedNum = 'Treinta y seis';
    //     break;
    //   case 37:
    //     this.translatedNum = 'Treinta y siete';
    //     break;
    //   case 38:
    //     this.translatedNum = 'Treinta y ocho';
    //     break;
    //   case 39:
    //     this.translatedNum = 'Treinta y nueve';
    //     break;
    //   case 40:
    //     this.translatedNum = 'Cuarenta';
    //     break;
    //   case 41:
    //     this.translatedNum = 'Cuarenta y uno';
    //     break;
    //   case 42:
    //     this.translatedNum = 'Cuarenta y dos';
    //     break;
    //   case 43:
    //     this.translatedNum = 'Cuarenta y tres';
    //     break;
    //   case 44:
    //     this.translatedNum = 'Cuarenta y cuatro';
    //     break;
    //   case 45:
    //     this.translatedNum = 'Cuarenta y cinco';
    //     break;
    //   case 46:
    //     this.translatedNum = 'Cuarenta y seis';
    //     break;
    //   case 47:
    //     this.translatedNum = 'Cuarenta y siete';
    //     break;
    //   case 48:
    //     this.translatedNum = 'Cuarenta y ocho';
    //     break;
    //   case 49:
    //     this.translatedNum = 'Cuarenta y nueve';
    //     break;
    //   case 50:
    //     this.translatedNum = 'Cincuenta';
    //     break;
    //   case 51:
    //     this.translatedNum = 'Cincuenta y uno';
    //     break;
    //   case 52:
    //     this.translatedNum = 'Cincuenta y dos';
    //     break;
    //   case 53:
    //     this.translatedNum = 'Cincuenta y tres';
    //     break;
    //   case 54:
    //     this.translatedNum = 'Cincuenta y cuatro';
    //     break;
    //   case 55:
    //     this.translatedNum = 'Cincuenta y cinco';
    //     break;
    //   case 56:
    //     this.translatedNum = 'Cincuenta y seis';
    //     break;
    //   case 57:
    //     this.translatedNum = 'Cincuenta y siete';
    //     break;
    //   case 58:
    //     this.translatedNum = 'Cincuenta y ocho';
    //     break;
    //   case 59:
    //     this.translatedNum = 'Cincuenta y nueve';
    //     break;
    //   case 60:
    //     this.translatedNum = 'Sesenta';
    //     break;
    //   case 61:
    //     this.translatedNum = 'Sesenta y uno';
    //     break;
    //   case 62:
    //     this.translatedNum = 'Sesenta y dos';
    //     break;
    //   case 63:
    //     this.translatedNum = 'Sesenta y tres';
    //     break;
    //   case 64:
    //     this.translatedNum = 'Sesenta y cuatro';
    //     break;
    //   case 65:
    //     this.translatedNum = 'Sesenta y cinco';
    //     break;
    //   case 66:
    //     this.translatedNum = 'Sesenta y seis';
    //     break;
    //   case 67:
    //     this.translatedNum = 'Sesenta y siete';
    //     break;
    //   case 68:
    //     this.translatedNum = 'Sesenta y ocho';
    //     break;
    //   case 69:
    //     this.translatedNum = 'Sesenta y nueve';
    //     break;
    //   case 70:
    //     this.translatedNum = 'Setenta';
    //     break;
    //   case 71:
    //     this.translatedNum = 'Setenta y uno';
    //     break;
    //   case 72:
    //     this.translatedNum = 'Setenta y dos';
    //     break;
    //   case 73:
    //     this.translatedNum = 'Setenta y tres';
    //     break;
    //   case 74:
    //     this.translatedNum = 'Setenta y cuatro';
    //     break;
    //   case 75:
    //     this.translatedNum = 'Setenta y cinco';
    //     break;
    //   case 76:
    //     this.translatedNum = 'Setenta y seis';
    //     break;
    //   case 77:
    //     this.translatedNum = 'Setenta y siete';
    //     break;
    //   case 78:
    //     this.translatedNum = 'Setenta y ocho';
    //     break;
    //   case 79:
    //     this.translatedNum = 'Setenta y nueve';
    //     break;
    //        case 80:
    //     this.translatedNum = 'Ochenta';
    //     break;
    //   case 81:
    //     this.translatedNum = 'Ochenta y uno';
    //     break;
    //   case 82:
    //     this.translatedNum = 'Ochenta y dos';
    //     break;
    //   case 83:
    //     this.translatedNum = 'Ochenta y tres';
    //     break;
    //   case 84:
    //     this.translatedNum = 'Ochenta y cuatro';
    //     break;
    //   case 85:
    //     this.translatedNum = 'Ochenta y cinco';
    //     break;
    //   case 86:
    //     this.translatedNum = 'Ochenta y seis';
    //     break;
    //   case 87:
    //     this.translatedNum = 'Ochenta y siete';
    //     break;
    //   case 88:
    //     this.translatedNum = 'Ochenta y ocho';
    //     break;
    //   case 89:
    //     this.translatedNum = 'Ochenta y nueve';
    //     break;
    //   default:
    //     break;
    // }
 
    if (number < 1 || number > 1000) {
      this.translatedNum = 'Número fuera de rango'; 
      return; 
    }

    const unidades = ['', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve'];
    const diezADiecinueve = ['diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve'];
    const decimas = ['', '', 'veinte', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
    const Cientos = ['', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos', 'seiscientos', 'setecientos', 'ochocientos', 'novecientos'];

    
    if (number === 0) {
      this.translatedNum = 'cero';
    }
   
    else if (number === 100) {
      this.translatedNum = 'cien';
    }
  
    else if (number < 10) {
      this.translatedNum = unidades[number];
    }

    else if (number < 20) {
      this.translatedNum = diezADiecinueve[number - 10];
    }
 
    else if (number < 100) {
      const unitDigit = number % 10;
      const tenDigit = Math.floor(number / 10);

      if (unitDigit === 0) {
        this.translatedNum = decimas[tenDigit];
      } else if (tenDigit === 2) {
        this.translatedNum = 'veinti' + unidades[unitDigit];
      } else {
        this.translatedNum = decimas[tenDigit] + ' y ' + unidades[unitDigit];
      }
    }
    
    else if (number < 1000) {
      const hundredDigit = Math.floor(number / 100);
      const remaining = number % 100;
      let tempResult = Cientos[hundredDigit]; 

      if (remaining > 0) {
        if (remaining < 10) {
          tempResult += ' ' + unidades[remaining];
        } else if (remaining < 20) {
          tempResult += ' ' + diezADiecinueve[remaining - 10];
        } else {
          const unitDigit = remaining % 10;
          const tenDigit = Math.floor(remaining / 10);
          if (unitDigit === 0) {
            tempResult += ' ' + decimas[tenDigit];
          } else if (tenDigit === 2) {
            tempResult += ' veinti' + unidades[unitDigit];
          } else {
            tempResult += ' ' + decimas[tenDigit] + ' y ' + unidades[unitDigit];
          }
        }
      }
      this.translatedNum = tempResult; 
    }
  
    else if (number === 1000) {
      this.translatedNum = 'mil';
    }
  }
}

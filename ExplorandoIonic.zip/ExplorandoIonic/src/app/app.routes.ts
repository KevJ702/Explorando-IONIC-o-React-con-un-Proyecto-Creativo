import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'sumadora',
    loadComponent: () => import('./sumadora/sumadora.page').then( m => m.SumadoraPage)
  },
  {
    path: 'traductor',
    loadComponent: () => import('./traductor/traductor.page').then( m => m.TraductorPage)
  },
  {
    path: 'tabla-multiplicar',
    loadComponent: () => import('./tabla-multiplicar/tabla-multiplicar.page').then( m => m.TablaMultiplicarPage)
  },
];

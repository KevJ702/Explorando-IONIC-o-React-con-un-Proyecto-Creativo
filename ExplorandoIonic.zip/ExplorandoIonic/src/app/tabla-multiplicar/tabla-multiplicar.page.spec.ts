import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TablaMultiplicarPage } from './tabla-multiplicar.page';

describe('TablaMultiplicarPage', () => {
  let component: TablaMultiplicarPage;
  let fixture: ComponentFixture<TablaMultiplicarPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(TablaMultiplicarPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

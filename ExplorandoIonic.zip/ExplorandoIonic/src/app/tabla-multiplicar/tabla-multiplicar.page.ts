import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-tabla-multiplicar',
  templateUrl: './tabla-multiplicar.page.html',
  styleUrls: ['./tabla-multiplicar.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class TablaMultiplicarPage implements OnInit {

  public num1 : number = 0;
  constructor() { }

  ngOnInit() {
  }

}

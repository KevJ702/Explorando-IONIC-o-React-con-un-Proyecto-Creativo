import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-BF4AXLRD.js";
import "./chunk-ZVATTXSA.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
